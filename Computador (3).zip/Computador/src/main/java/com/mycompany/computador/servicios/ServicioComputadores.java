/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computador.servicios;

import com.mycompany.computador.model.Computador;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author ORIANA BONILLA
 */
public class ServicioComputadores {
    
    public static boolean guardarEnArchivo(Computador comp){
        try {
            RandomAccessFile file = new RandomAccessFile("data//ejemplo.txt", "rw");            
            file.seek(file.length());
            file.writeInt(comp.getIdentificacion());
            file.writeUTF(comp.getModelo());
            file.writeDouble(comp.getPrecio());
            file.writeBoolean(comp.isTarjetaVideo());
            file.writeUTF(comp.getEstado());
            file.close();
        } catch (Exception ex) {
            System.out.println("error de guardado");
            return false;
        }
        
        return true;
    }
 public static List getComputadores(){
        //Se declara una variable llamada empleados de tipo ArrayList que permite "almacenar" objetos de tipo empleado
        List <Computador> computadores = new ArrayList();
        int identificacion;
        String modelo;
        double precio;
        boolean tarjetaVideo;
        String estado;
        //Variable de tipo empleado - NO hay objeto aún
        Computador comp = null;
        
        try {
            RandomAccessFile file = new RandomAccessFile("data//ejemplo.txt", "rw");
            //Se posiciona al inicio del archivo
            file.seek(0);
            while(file.getFilePointer() < file.length()){
                //lee los datos del archivo y los almacena en tres variables diferentes
                identificacion = file.readInt();
                modelo = file.readUTF();
                precio = file.readDouble();
                tarjetaVideo = file.readBoolean();
                estado = file.readUTF();
                //Crea un objeto de tipo Empleado (emp) a partir de los valores leidos del archivo. 
                comp = new Computador(identificacion, modelo, precio, tarjetaVideo, estado);
                //Se adiciona al ArrayList empleados el empleado leido
                computadores.add(comp);
            }
            file.close();
        } catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        return computadores;
    }
        public static double SumaPrecio()
 {
     double suma = 0;
     int cantidad = 0;
     
     try 
     {
         RandomAccessFile file = new RandomAccessFile("data//ejemplo.txt", "rw");
            
         while (file.getFilePointer() < file.length())
         {
             int identificacion = file.readInt();
             String modelo = file.readUTF();
             double Precio = file.readDouble();
             boolean tarjetaVideo = file.readBoolean();
             String esstado = file.readUTF();
             
             
             suma += Precio;
         }
     file.close();
     } catch (Exception e) {
     } 
   return suma;        
 } 
}
