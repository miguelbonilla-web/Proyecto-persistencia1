/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computador.model;

/**
 *
 * @author ORIANA BONILLA
 */
public class Computador 
{
    
    
    public static final int TAM_MODELO = 12;
    public static final int TAM_ESTADO = 10;
    
    private int identificacion;
    private String modelo;
    private Double precio;
    private boolean tarjetaVideo;
    private String estado;

    public Computador(int identificacion, String modelo, double precio, boolean tarjetaVideo, String estado) {
        this.identificacion = identificacion;
        this.modelo = modelo;
        this.precio = precio;
        this.tarjetaVideo = tarjetaVideo;
        this.estado = estado;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public boolean isTarjetaVideo() {
        return tarjetaVideo;
    }

    public void setTarjetaVideo(boolean tarjetaVideo) {
        this.tarjetaVideo = tarjetaVideo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
}
