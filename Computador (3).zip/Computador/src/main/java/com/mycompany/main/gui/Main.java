/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main.gui;

import com.mycompany.computador.gui.GUIComputador;


/**
 *
 * @author ORIANA BONILLAD
 */
public class Main {
    
    
    public static void main(String[] args) {
        GUIComputador gui = new GUIComputador();
        gui.setVisible(true);
    }
    
}
